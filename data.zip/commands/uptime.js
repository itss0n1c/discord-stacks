module.exports = {
    name: "uptime",
    description: "Sends the uptime of bot.",
    handler() {
        return "WIP"
    }
}