module.exports = {
    name: "eval",
    description: "Literally runs JS through the bot, owner permission only!",
    ownerOnly: true,
    arguments: {
        typeof: 'string'
    },
    handler() {
        return "WIP"
    }
}