# discord-stacks
A JS-like command system for Discord Bots

```
npm i discord-stacks
```